# Copilot-Instructions — 10-24-25

**Keep this short.** Gating, read order, and standards live in `/docs/Protocol_10-24-25.md`.

---

## Prompt Skeleton (strict order)
1) **Read List** (paths): `/docs/Protocol_10-24-25.md`, `/docs/code-review.md` (last 3 lines), <story file>, <test file>
2) **Story ID + Sprint Goal** (exact text)
3) **Expected Behavior** — 3–6 **Given/When/Then** lines including **edge + error**
4) **Constraints** — ≤2 files, ≤60 LOC (unless refactor story); tests-first; no unrelated edits
5) **Artifacts** — screenshots/paths as needed
6) **After-Green** — append the Decisions line; echo it
7) **Confirmation** — reply **PROCEED / REVISE / BLOCK**

---

## Do
- Read the Protocol first; mirror its sections and language.
- Write tests first; stop if red and return **REVISE** with failing spec title + error.
- Use **Probe‑First** when selectors/routes are unknown.
- Keep diffs minimal; defer refactors to a separate story.

## Don’t
- Don’t paste long histories; link by path.
- Don’t touch unrelated files.
- Don’t proceed without GREEN tests + Decisions line.

**End**
