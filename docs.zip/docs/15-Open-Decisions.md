# Open Decisions

- Pilot **neighborhood polygon** (14th–42nd corridor exact boundaries).
- **Pilot year** (choose for PD-rich sources—1900/1910/1940 are candidates).
- Default **Detour Budget** (recommend 5% cap; hard cap 10%).
- **Interest taxonomy** finalization (labels & merges).
- **Power rubric** examples & edge cases.
- **Sensitive sites** policy details.
- **Educator features** for freemium/paid tiers.
- **Authority IDs** (confirm set: VIAF/ISNI/LCNAF/Wikidata).
