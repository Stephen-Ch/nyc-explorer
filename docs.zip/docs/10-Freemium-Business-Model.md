# Freemium Business Model

## Free
- One neighborhood × one year.
- Full citations; Save list.

## Upgrade
- Unlock additional years & neighborhoods.
- **Theme packs:** performance venues; restaurants & businesses.
- Extras: audio micro-stories, advanced filters, export & educator guides.

## Pricing Hints (TBD)
- Neighborhood pack (all years): $4.99–$9.99
- Annual pass: $19–$39
- Institutional/education license: site-based pricing.
