# Governance, Rights & Ethics

- **Rights posture:** embed only PD/CC0/permitted CC; otherwise link-out with thumbnail if allowed.
- **Attribution:** footnotes for all claims; archives credited by preferred citation.
- **Sensitive content:** balanced tone, context forward; obey takedown/opt-out where warranted.
- **Versioning:** no source deletion; supersede with new claims; maintain audit trail.
- **Analytics:** privacy-first; aggregate stats only; no individual path tracking beyond ephemeral routing.
